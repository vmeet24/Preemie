package com.example.medico.Notifications;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.medico.R;

public class EquipmentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_equipments);
    }
}
