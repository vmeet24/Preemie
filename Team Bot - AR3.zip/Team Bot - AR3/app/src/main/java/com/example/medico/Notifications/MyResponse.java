package com.example.medico.Notifications;

public class MyResponse {

    public int success;
}
